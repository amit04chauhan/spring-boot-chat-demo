package com.example.chatmessagingapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatMessagingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
