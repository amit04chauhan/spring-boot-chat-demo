package com.example.chatmessagingapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatMessagingAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChatMessagingAppApplication.class, args);
	}

}
