package com.example.chatmessagingapp.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.io.Serializable;

@Data
@AllArgsConstructor
@Document(collection = "user")
public class User implements Serializable {
    @Id
    @Field("_id")
    private String userId;
    private String username;
    private String email;
    private String address;
    private String mobileNo;

    public User() {
        userId = new ObjectId().toString();
    }

}
