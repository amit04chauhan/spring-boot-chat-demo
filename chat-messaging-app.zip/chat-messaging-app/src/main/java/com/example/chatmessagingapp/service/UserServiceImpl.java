package com.example.chatmessagingapp.service;

import com.example.chatmessagingapp.entity.User;
import com.example.chatmessagingapp.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public String userSignUp(User user) {
        User retrievedUser = userRepository.findByMobileNo(user.getMobileNo());
        if(retrievedUser != null) {
            return "User already present with provided mobile number!";
        }
        User userResponse = userRepository.save(user);
        return "User signed up successfully with userId : "+userResponse.getUserId();
    }
}
