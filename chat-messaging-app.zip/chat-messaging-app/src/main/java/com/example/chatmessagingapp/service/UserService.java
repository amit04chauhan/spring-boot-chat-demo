package com.example.chatmessagingapp.service;

import com.example.chatmessagingapp.entity.User;

public interface UserService {

    String userSignUp(User user);
}
