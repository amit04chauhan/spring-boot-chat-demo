package com.example.chatmessagingapp.controller;

import com.example.chatmessagingapp.entity.User;
import com.example.chatmessagingapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/signUp")
    public ResponseEntity<?> userSignUp(@RequestBody User user) {
        String response = userService.userSignUp(user);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
