package com.example.chatmessagingapp.controller;

import com.example.chatmessagingapp.dto.RequestDeleteMessageDto;
import com.example.chatmessagingapp.dto.ResponseReadMessageDto;
import com.example.chatmessagingapp.entity.Chat;
import com.example.chatmessagingapp.service.ChatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/chat")
public class ChatController {

    @Autowired
    private ChatService chatService;

    @PostMapping("/sendMessage")
    public ResponseEntity<?> sendMessage(@RequestBody Chat chat) {
        String response = chatService.sendMessage(chat);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/readMessage")
    public ResponseEntity<?> readAllMessagesFromParticularUser(@RequestParam String senderUserId,
                                                               @RequestParam String receiverUserId) {
        List<ResponseReadMessageDto> responseList = chatService.readAllMessagesFromParticularUser(senderUserId, receiverUserId);
        if(responseList == null || responseList.isEmpty())
        {
            return new ResponseEntity<>("No messages found!",HttpStatus.OK);
        }
        return new ResponseEntity<>(responseList,HttpStatus.OK);
    }

    @PutMapping("/deleteMessage")
    public ResponseEntity<?> deleteMessage(@RequestBody RequestDeleteMessageDto requestDto) {
        chatService.deleteMessage(requestDto);
        return new ResponseEntity<>("Message Deleted Successfully",HttpStatus.OK);
    }


}
