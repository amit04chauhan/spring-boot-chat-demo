package com.example.chatmessagingapp.service;

import com.example.chatmessagingapp.dto.RequestDeleteMessageDto;
import com.example.chatmessagingapp.dto.ResponseReadMessageDto;
import com.example.chatmessagingapp.entity.Chat;

import java.util.List;

public interface ChatService {
    String sendMessage(Chat chat);

    List<ResponseReadMessageDto> readAllMessagesFromParticularUser(String senderUserId, String receiverUserId);

    void deleteMessage(RequestDeleteMessageDto requestDto);
}
