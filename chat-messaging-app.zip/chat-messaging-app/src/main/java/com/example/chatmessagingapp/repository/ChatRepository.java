package com.example.chatmessagingapp.repository;

import com.example.chatmessagingapp.entity.Chat;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface ChatRepository extends MongoRepository<Chat, Object> {

    List<Chat> findBySenderUserIdAndReceiverUserId(String senderUserId, String receiverUserId);

    Chat findByChatId(String chatId);
}
