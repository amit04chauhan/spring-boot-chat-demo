package com.example.chatmessagingapp.service;

import com.example.chatmessagingapp.dto.RequestDeleteMessageDto;
import com.example.chatmessagingapp.dto.ResponseReadMessageDto;
import com.example.chatmessagingapp.entity.Chat;
import com.example.chatmessagingapp.repository.ChatRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class ChatServiceImpl implements ChatService {

    @Autowired
    private ChatRepository chatRepository;

    @Override
    public String sendMessage(Chat chat) {
        chat.setTimestamp(LocalDateTime.now().toString());
        chat.setSenderStatus(1);
        chat.setReceiverStatus(1);
        chatRepository.save(chat);

        return "Message sent!";
    }

    @Override
    public List<ResponseReadMessageDto> readAllMessagesFromParticularUser(String senderUserId, String receiverUserId) {
        List<Chat> allChats = chatRepository.findBySenderUserIdAndReceiverUserId(senderUserId, receiverUserId);
        List<ResponseReadMessageDto> responseList = new ArrayList<>();
        if(allChats != null && !allChats.isEmpty())
        {
            for(Chat c : allChats) {
                if(c.getSenderStatus() == 5 || c.getReceiverStatus() == 5) {
                    continue;
                }
                ResponseReadMessageDto response = new ResponseReadMessageDto(c.getTimestamp(),c.getMessage());
                c.setReceiverStatus(2);
                responseList.add(response);
            }
            chatRepository.saveAll(allChats);
        }
        return responseList;
    }

    @Override
    public void deleteMessage(RequestDeleteMessageDto requestDto) {
        String chatId = requestDto.getChatId();
        Integer cStatus = requestDto.getUserStatus();

        Chat chat = chatRepository.findByChatId(chatId);

        if(cStatus == 1)
        {
            chat.setSenderStatus(5);
        } else if(cStatus == 2){
            chat.setReceiverStatus(5);
        } else
            return;

        chatRepository.save(chat);
    }

}
